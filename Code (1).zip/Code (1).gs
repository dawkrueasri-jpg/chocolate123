// Google Apps Script: วางใน Extensions > Apps Script ของ Google Sheet
// Sheet ชื่อ "Orders" แถวแรก (หัวคอลัมน์):
// Timestamp | OrderID | Name | Phone | Address | SKU | Product | Qty | Price | Total | Status
function doPost(e) {
  const sh = SpreadsheetApp.getActive().getSheetByName("Orders");
  const d = JSON.parse(e.postData.contents);
  const id = "BN" + Utilities.formatDate(new Date(), "Asia/Bangkok", "yyMMddHHmmss");
  sh.appendRow([new Date(), id, d.name, d.phone, d.address, d.sku, d.product, d.qty, d.price, d.total, "รอแพ็ค"]);
  return ContentService.createTextOutput("ok");
}
// ใช้กับหน้า packing.html (ดึงออเดอร์ไปทำใบหยิบสินค้า + ใบจ่าหน้าพัสดุ)
function doGet() {
  const rows = SpreadsheetApp.getActive().getSheetByName("Orders").getDataRange().getValues();
  const head = rows.shift();
  const out = rows.map(r => Object.fromEntries(head.map((h, i) => [h, r[i]])));
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}
